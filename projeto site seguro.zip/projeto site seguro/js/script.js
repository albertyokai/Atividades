function validarFormulario() {
  const nomes = [
    { nomes: "admin", senha: "123" },
    { nomes: "user", senha: "1234" },
    { nomes: "Robs", senha: "abc" },
    { nomes: "João", senha: "def" },
    { nomes: "Leandro", senha: "777" },
    { nomes: "Fred", senha: "6767" },
    { nomes: "Albert", senha: "321" },
    { nomes: "Maria", senha: "171" },
    { nomes: "Isabela", senha: "621" },
    { nomes: "Ane", senha: "111" },
  ];

  document
    .getElementById("formLogin")
    .addEventListener("submit", function (event) {
      event.preventDefault();

      const user = document.getElementById("nome").value;
      const senha = document.getElementById("senha").value;

      const logado = nomes.find(
        (x) => x.nomes === user && x.senha === senha,
      );

      if (logado) {
        sessionStorage.setItem("usuarioLogado", logado.nomes);
        window.location.href = "pages/home.html";
      } else {
        alert("Usuário ou senha inválidos!");
      }
    });
}
